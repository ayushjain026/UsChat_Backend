const { initializeApp } = require("firebase/app");
const { getAuth } = require("firebase/auth");
const { getFirestore } = require("firebase/firestore");
const admin = require("firebase-admin");

// Firebase admin credentails for email-password auth
const credentails = require("./serviceAccountKey");
admin.initializeApp({
  credentails: admin.credential.cert(credentails)
});

// Your web app's Firebase configuration
const firebaseConfig = require("./firebaseConfiguration");

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firestore (the database service)
const db = getFirestore(app);

// Get Firebase Authentication
const auth = getAuth(app);

module.exports = { db, auth, admin };
